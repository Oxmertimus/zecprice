# zecprice

A simple app that displays the current price of ZEC (Zcash).

## Setup

```bash
npm install
```

## Usage

```bash
npm start
```

